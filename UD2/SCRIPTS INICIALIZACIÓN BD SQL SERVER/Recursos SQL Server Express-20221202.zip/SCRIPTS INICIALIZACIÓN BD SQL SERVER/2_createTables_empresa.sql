USE [empresa];
GO

IF OBJECT_ID(N'dbo.DEPT', N'U') IS  NULL
BEGIN
    CREATE TABLE [dbo].[DEPT](
	[DEPTNO] [int] IDENTITY(1,1) PRIMARY KEY,
	[DNAME] [varchar](20) NULL,
	[LOC] [varchar](20) NULL,

);

END

IF OBJECT_ID(N'dbo.EMP', N'U') IS  NULL
BEGIN
  CREATE TABLE [dbo].[EMP](
	[EMPNO] [int] IDENTITY(1,1) PRIMARY KEY,
	[ENAME] [varchar](20) NULL,
	[JOB] [varchar](20) NULL,
	[MGR] [int] FOREIGN KEY REFERENCES EMP(EMPNO) NULL,
	[HIREDATE] [date] NULL,
	[SAL] [money] NULL,
	[COMM] [money] NULL,
	DEPTNO INT FOREIGN KEY REFERENCES DEPT(DEPTNO) );
END
GO
