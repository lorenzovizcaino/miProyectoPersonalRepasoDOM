package es.teis.model.dao.partido;

import es.teis.data.exceptions.InstanceNotFoundException;
import es.teis.db.DBCPDataSourceFactory;
import es.teis.model.Partido;
import es.teis.model.dao.AbstractGenericDao;

import javax.sql.DataSource;
import java.sql.*;

public class PartidoSQLServerDao extends AbstractGenericDao<Partido> implements IPartidoDao {

    private DataSource dataSource;

    public PartidoSQLServerDao() {
        this.dataSource = DBCPDataSourceFactory.getDataSource();
    }

    @Override
    public Partido create(Partido entity) {
        try (
                Connection conexion = this.dataSource.getConnection();
                PreparedStatement pstmt = conexion.prepareStatement(
                        "INSERT INTO [dbo].[PARTIDO]\n" +
                                "           ([nombre]\n" +
                                "           ,[porcentaje]\n" +
                                "           ,[numero_votos])\n" +
                                "     VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS
                );) {

            pstmt.setString(1, entity.getNombre());
            pstmt.setInt(2, entity.getVotos());
            pstmt.setFloat(3, entity.getPorcentaje());
            int result = pstmt.executeUpdate();
            ResultSet clavesResultado = pstmt.getGeneratedKeys();

            if (clavesResultado.next()) {
                int partidoId = clavesResultado.getInt(1);
                entity.setId(partidoId);
            } else {
                entity = null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("Ha ocurrido una excepción: " + e.getMessage());
            entity = null;
        }
        return entity;
    }

    @Override
    public Partido read(int id) throws InstanceNotFoundException {
        return null;
    }

    @Override
    public boolean update(Partido entity) {
        return false;
    }

    @Override
    public boolean delete(int id) {
        return false;
    }

    @Override
    public boolean existePartido(String nombre) {
        boolean retorno = false;
        try (
                Connection conexion = this.dataSource.getConnection();
                PreparedStatement sentencia = conexion.prepareStatement("select * from partido where nombre=?");) {
            sentencia.setString(1, nombre);

            ResultSet result = sentencia.executeQuery();
            if (result.next()) {
                retorno=true;

            } else {
                retorno=false;
            }


        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Ha ocurrido una excepcion");
        }
        return retorno;
    }

    @Override
    public boolean transferirVotos(String nombreOrigen, String nombreDestino, int cantidadVotos) throws SQLException {

        boolean exito = false;
        Connection con = null;
        PreparedStatement updateOrigen = null;
        PreparedStatement updateDestino = null;
        try {
            con = this.dataSource.getConnection();

            updateOrigen = con.prepareStatement("UPDATE [dbo].[PARTIDO]\n"
                    + "   SET [numero_votos] = (numero_votos - ?) \n"
                    + " WHERE nombre = ?");
            updateDestino = con.prepareStatement("UPDATE [dbo].[PARTIDO]\n"
                    + "   SET [numero_votos] = (numero_votos + ?) \n"
                    + " WHERE nombre = ?");
            con.setAutoCommit(false);
            updateOrigen.setInt(1, cantidadVotos);
            updateOrigen.setString(2, nombreOrigen);
            updateOrigen.executeUpdate();

            updateDestino.setInt(1, cantidadVotos);
            updateDestino.setString(2, nombreDestino);
            updateDestino.executeUpdate();
            con.commit();
            exito = true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            System.err.println("Ha habido una excepción. " + ex.getMessage());
            con.rollback();
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    System.err.println("Ha habido una excepción cerrando la conexión: " + ex.getMessage());
                }
            }
        }
        return exito;
    }
}
